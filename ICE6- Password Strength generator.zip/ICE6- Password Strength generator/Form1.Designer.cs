﻿namespace ICE6__Password_Strength_generator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.lowercaselabel = new System.Windows.Forms.Label();
            this.UppercaseLabel = new System.Windows.Forms.Label();
            this.digitsLabel = new System.Windows.Forms.Label();
            this.SpecialcharLabel = new System.Windows.Forms.Label();
            this.LenghCharLabel = new System.Windows.Forms.Label();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.HintToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.RevealcheckBox = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.PasswordTextBox, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.progressBar1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 0, 6);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 580);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(774, 62);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter a password";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(774, 62);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password Strength";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 402);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(774, 62);
            this.label3.TabIndex = 2;
            this.label3.Text = "Requirement";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordTextBox.Font = new System.Drawing.Font("Consolas", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTextBox.Location = new System.Drawing.Point(13, 98);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(774, 54);
            this.PasswordTextBox.TabIndex = 3;
            this.PasswordTextBox.TextChanged += new System.EventHandler(this.PasswordTextBox_TextChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Controls.Add(this.RevealcheckBox);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(13, 167);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(774, 71);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.progressBar1.Location = new System.Drawing.Point(13, 321);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(774, 71);
            this.progressBar1.TabIndex = 5;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.lowercaselabel);
            this.flowLayoutPanel2.Controls.Add(this.UppercaseLabel);
            this.flowLayoutPanel2.Controls.Add(this.digitsLabel);
            this.flowLayoutPanel2.Controls.Add(this.SpecialcharLabel);
            this.flowLayoutPanel2.Controls.Add(this.LenghCharLabel);
            this.flowLayoutPanel2.Controls.Add(this.flowLayoutPanel3);
            this.flowLayoutPanel2.Controls.Add(this.label6);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(13, 475);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(774, 71);
            this.flowLayoutPanel2.TabIndex = 6;
            // 
            // lowercaselabel
            // 
            this.lowercaselabel.BackColor = System.Drawing.Color.IndianRed;
            this.lowercaselabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowercaselabel.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lowercaselabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lowercaselabel.Location = new System.Drawing.Point(3, 0);
            this.lowercaselabel.Name = "lowercaselabel";
            this.lowercaselabel.Size = new System.Drawing.Size(99, 64);
            this.lowercaselabel.TabIndex = 6;
            this.lowercaselabel.Text = "a-z";
            this.lowercaselabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HintToolTip.SetToolTip(this.lowercaselabel, "Password must contain at least one lower case letter");
            // 
            // UppercaseLabel
            // 
            this.UppercaseLabel.BackColor = System.Drawing.Color.IndianRed;
            this.UppercaseLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UppercaseLabel.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UppercaseLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UppercaseLabel.Location = new System.Drawing.Point(144, 0);
            this.UppercaseLabel.Margin = new System.Windows.Forms.Padding(39, 0, 3, 0);
            this.UppercaseLabel.Name = "UppercaseLabel";
            this.UppercaseLabel.Size = new System.Drawing.Size(103, 64);
            this.UppercaseLabel.TabIndex = 7;
            this.UppercaseLabel.Text = "A-Z";
            this.UppercaseLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HintToolTip.SetToolTip(this.UppercaseLabel, "Password must contain at least one Upper case letter");
            // 
            // digitsLabel
            // 
            this.digitsLabel.BackColor = System.Drawing.Color.IndianRed;
            this.digitsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.digitsLabel.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digitsLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.digitsLabel.Location = new System.Drawing.Point(289, 0);
            this.digitsLabel.Margin = new System.Windows.Forms.Padding(39, 0, 3, 0);
            this.digitsLabel.Name = "digitsLabel";
            this.digitsLabel.Size = new System.Drawing.Size(101, 64);
            this.digitsLabel.TabIndex = 9;
            this.digitsLabel.Text = "0-9";
            this.digitsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HintToolTip.SetToolTip(this.digitsLabel, "Password must contain at least one number");
            // 
            // SpecialcharLabel
            // 
            this.SpecialcharLabel.BackColor = System.Drawing.Color.IndianRed;
            this.SpecialcharLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SpecialcharLabel.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpecialcharLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SpecialcharLabel.Location = new System.Drawing.Point(432, 0);
            this.SpecialcharLabel.Margin = new System.Windows.Forms.Padding(39, 0, 3, 0);
            this.SpecialcharLabel.Name = "SpecialcharLabel";
            this.SpecialcharLabel.Size = new System.Drawing.Size(102, 64);
            this.SpecialcharLabel.TabIndex = 10;
            this.SpecialcharLabel.Text = "!@";
            this.SpecialcharLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HintToolTip.SetToolTip(this.SpecialcharLabel, "Password must contain at least one specil charcater");
            // 
            // LenghCharLabel
            // 
            this.LenghCharLabel.BackColor = System.Drawing.Color.IndianRed;
            this.LenghCharLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LenghCharLabel.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LenghCharLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LenghCharLabel.Location = new System.Drawing.Point(576, 0);
            this.LenghCharLabel.Margin = new System.Windows.Forms.Padding(39, 0, 3, 0);
            this.LenghCharLabel.Name = "LenghCharLabel";
            this.LenghCharLabel.Size = new System.Drawing.Size(183, 64);
            this.LenghCharLabel.TabIndex = 11;
            this.LenghCharLabel.Text = "10 chars";
            this.LenghCharLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.HintToolTip.SetToolTip(this.LenghCharLabel, "Password must contain at least 10 letters");
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.label5);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 67);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(774, 0);
            this.flowLayoutPanel3.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.IndianRed;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 74);
            this.label5.TabIndex = 6;
            this.label5.Text = "a-z";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.IndianRed;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(3, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 74);
            this.label6.TabIndex = 8;
            this.label6.Text = "a-z";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::ICE6__Password_Strength_generator.Properties.Resources.Die;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 55);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RevealcheckBox
            // 
            this.RevealcheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.RevealcheckBox.BackgroundImage = global::ICE6__Password_Strength_generator.Properties.Resources.close;
            this.RevealcheckBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.RevealcheckBox.Checked = true;
            this.RevealcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RevealcheckBox.FlatAppearance.BorderSize = 0;
            this.RevealcheckBox.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.RevealcheckBox.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.RevealcheckBox.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.RevealcheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RevealcheckBox.Location = new System.Drawing.Point(116, 3);
            this.RevealcheckBox.Name = "RevealcheckBox";
            this.RevealcheckBox.Size = new System.Drawing.Size(141, 55);
            this.RevealcheckBox.TabIndex = 1;
            this.RevealcheckBox.UseVisualStyleBackColor = true;
            this.RevealcheckBox.CheckedChanged += new System.EventHandler(this.RevealPasswordCheck);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 580);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bahara Nazari- Password Generator";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox RevealcheckBox;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lowercaselabel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label UppercaseLabel;
        private System.Windows.Forms.Label digitsLabel;
        private System.Windows.Forms.Label SpecialcharLabel;
        private System.Windows.Forms.Label LenghCharLabel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolTip HintToolTip;
    }
}

