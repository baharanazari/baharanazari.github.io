﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICE6__Password_Strength_generator
{

   
    public static class ProgressBarExtension

    {
        [DllImport("uxtheme.dll")]
        static extern int SetWindowTheme(IntPtr hwnd, string appName="",string partList="");


        // progressbar1.DisableStyle
        public static void DisableStyle(this ProgressBar progressBar)
        {
            SetWindowTheme(progressBar.Handle);
        }
    }
}
