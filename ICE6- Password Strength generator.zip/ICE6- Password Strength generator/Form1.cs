﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICE6__Password_Strength_generator
{
    public partial class Form1 : Form
    {

        const String LowerCase = "abcdefghijklmnopqrstuvwxyz";
        const String UpperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const string Digits = "0123456789";
        const string SpecialChar = "~!@#$%^&*()_-+={}[]||\\:;/><.,";

        bool isLower, isUpper, isDigit, isSpecial, isTenChar;
        public Form1()
        {


            InitializeComponent();
            progressBar1.DisableStyle();
        }
        void GeneratePassword()
        {

            string password = "";
            Random random = new Random();
            string[] criteria = { LowerCase, UpperCase, Digits, SpecialChar };
            bool isStrong;
            // generate 10 chars

            do
            {



                for (int count = 0; count < 10; count++)
                {// pick a random criteria 
                    string criterion = criteria[random.Next(criteria.Length)];
                    // pick a random letter from that croiterion 
                    char letter = criterion[random.Next(criteria.Length)];
                    // add the letter 
                    password += letter;

                }CheckPasswordStrength(password);
                
                isStrong = (isLower && isUpper && isSpecial && isDigit && isTenChar);

            }while(!isStrong);

            PasswordTextBox.Text = password;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GeneratePassword();
        }

        /// <summary>
        /// reavel and conceal the password
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RevealPasswordCheck(object sender, EventArgs e)
        {
            //reveal the password when checked
            if (RevealcheckBox.Checked)
            {
                PasswordTextBox.UseSystemPasswordChar = false;
                RevealcheckBox.BackgroundImage = Properties.Resources.open;
            }

            //canceal the password when checked
            else
            {
                PasswordTextBox.UseSystemPasswordChar = true;
                RevealcheckBox.BackgroundImage = Properties.Resources.close;
            }

        }
        /// <summary>
        /// check the password strength and update the progressbar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {
            CheckPasswordStrength(PasswordTextBox.Text);
            UpadteProgressColors();
        }

        private void UpadteProgressColors()
        {   //using ternary operator to change back color 
            
            lowercaselabel.BackColor = isLower?  Color.Green: Color.Firebrick;
            UppercaseLabel.BackColor = isUpper ? Color.Green : Color.Firebrick;
            digitsLabel.BackColor = isDigit ? Color.Green : Color.Firebrick;
            SpecialcharLabel.BackColor = isSpecial ? Color.Green : Color.Firebrick;
            LenghCharLabel.BackColor = isTenChar ? Color.Green : Color.Firebrick;

            //upadte 
            progressBar1.Value = 0;
            progressBar1.Value += isLower ? 20 : 0;
            progressBar1.Value += isUpper ? 20 : 0;
            progressBar1.Value += isDigit ? 20 : 0;
            progressBar1.Value += isSpecial ? 20 : 0;
            progressBar1.Value += isTenChar ? 20 : 0;

            // progress color 
            if(progressBar1.Value ==20)
                progressBar1.ForeColor = Color.Red;
            else if (progressBar1.Value ==40)
                progressBar1.ForeColor = Color.Plum;
            else if(progressBar1.Value ==60)
                progressBar1.ForeColor = Color.Yellow;
            else if(progressBar1.Value ==80)
                progressBar1.ForeColor= Color.Lime ;
            else if(progressBar1.Value ==100)
                progressBar1.ForeColor = Color.Violet;
                


        }
        /// <summary>
        /// ceheck if the password meeth the regiurement 
        /// </summary>
        private void CheckPasswordStrength(string password)
        {
            // check if meet critira

            isLower = false;
            isUpper = false;
            isDigit = false;
            isSpecial = false;
            isTenChar = false;
                
            
            foreach (char letter in password)
            {
                if (LowerCase.Contains(letter))
                    isLower = true;
                else if (UpperCase.Contains(letter))
                    isUpper = true;
                else if (Digits.Contains(letter))
                    isDigit = true;
                else if (SpecialChar.Contains(letter))
                    isSpecial = true;
            }

            if (password.Length >= 10)
            {
                isTenChar = true;
            }
        }
    }
}
