﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICE5_Emoji_Matching_Game
{

    
    public partial class Form1 : Form
    {    // the clciked labels 
        Label firstLabel = null, secondLabel= null;
        /// <summary>
        /// Its gonna choose random emoji to a square
        /// </summary>
        private void AssignEmojiToSquares()
        {
            // 16 emoji in total, but 8 pairs 
            List<string> EmojiList = new List<string>
        {
            "💀","😈","💖","👹","😏","🦧","👽","😵‍💫",
            "💀","😈","💖","👹","😏","🦧","👽","😵‍💫",

        };

            // choose a randon emoji for each square
            Random random = new Random();
            foreach (Label sqaure in tableLayoutPanel1.Controls )
            {
                //generate a random index 
                int index = random.Next(EmojiList.Count);
                // add the emoji to the label 
                sqaure.Text = EmojiList[index];

                // remove the emoji from the list 
                EmojiList.RemoveAt(index);
                // make the emoji invisble by matching the fore back colours
                sqaure.ForeColor = sqaure.BackColor;

                
            }

        }

       void  ChechForWinner()
        {
            // go through all emoji 
            foreach(Label emoji in tableLayoutPanel1.Controls)
            {
                // if we find one that not clciked , then we didnt woin 
                // the forcolor/ back colours dont match 

                if (emoji.ForeColor == emoji.BackColor)
                    return;// dose nothing 
            }
            // went through all emoji 
            // none of them is uncliked 
            // you win message 

            MessageBox.Show("YAAAAY! You win Buddy ");
            AssignEmojiToSquares();
        }

        public Form1()
        {
            InitializeComponent();
            AssignEmojiToSquares();
        }
        /// <summary>
        /// 
        /// called when 2 emoji dont match 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TimesUp(object sender, EventArgs e)
        {  // stop the timer 
            peekTimer.Stop();
            
            // hide the labels 
            firstLabel.ForeColor = firstLabel.BackColor;
            secondLabel.ForeColor = secondLabel.BackColor;
            // reset the label 
            firstLabel = null;
            secondLabel = null;
        }
        /// <summary>
        /// called whenever any squre is clicked 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ClickedAnyLabel(object sender, EventArgs e)
        {
            // get the clicked label 
            Label clickedLabel = sender as Label;
            // avoid clicking the same emoji again
            if(clickedLabel.BackColor!= clickedLabel.ForeColor) return;
            // clicked the first emoji 
            if (firstLabel == null && secondLabel == null)
            {
                firstLabel = clickedLabel;
                clickedLabel.ForeColor = Color.Red;
            }
            else if (firstLabel != null && secondLabel == null)
            {
                secondLabel = clickedLabel;
                clickedLabel.ForeColor = Color.Red;

                // emoji match 
                if(firstLabel.Text == secondLabel.Text)
                {
                    // reset the clicked label 
                    firstLabel = null;
                    secondLabel = null;
                    /// did we win 
                    ChechForWinner();
                    
                }
                // emoji dont match - hide the labels 
                else
                
                    peekTimer.Start();
                
            }
            // Debugging
            // Debug.WriteLine("Click" + clickedLabel.Text);

            

           

        }
    }
}
